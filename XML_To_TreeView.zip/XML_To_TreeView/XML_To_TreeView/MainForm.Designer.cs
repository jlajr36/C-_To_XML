﻿/*
 * Created by SharpDevelop.
 * User: Main
 * Date: 10/27/2019
 * Time: 6:24 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace XML_To_TreeView
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.tvData = new System.Windows.Forms.TreeView();
			this.btnLoad = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// tvData
			// 
			this.tvData.Location = new System.Drawing.Point(12, 12);
			this.tvData.Name = "tvData";
			this.tvData.Size = new System.Drawing.Size(227, 307);
			this.tvData.TabIndex = 0;
			// 
			// btnLoad
			// 
			this.btnLoad.Location = new System.Drawing.Point(254, 12);
			this.btnLoad.Name = "btnLoad";
			this.btnLoad.Size = new System.Drawing.Size(75, 23);
			this.btnLoad.TabIndex = 1;
			this.btnLoad.Text = "Load";
			this.btnLoad.UseVisualStyleBackColor = true;
			this.btnLoad.Click += new System.EventHandler(this.BtnLoadClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(344, 331);
			this.Controls.Add(this.btnLoad);
			this.Controls.Add(this.tvData);
			this.Name = "MainForm";
			this.Text = "XML To TreeView";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnLoad;
		private System.Windows.Forms.TreeView tvData;
	}
}
