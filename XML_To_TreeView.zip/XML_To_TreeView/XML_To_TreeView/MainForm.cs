﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace XML_To_TreeView
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}
		
		void BtnLoadClick(object sender, EventArgs e)
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog()) {
				openFileDialog.Filter = "Xml Files (*.xml)|*.xml";
				if (openFileDialog.ShowDialog() == DialogResult.OK) {
					XmlReader xmlReader = XmlReader.Create(openFileDialog.FileName);
					
					
					string strid = "";
					TreeNode pName = new TreeNode();
					TreeNode ava = new TreeNode();
					TreeNode price = new TreeNode();
					//TreeNode[] part = new TreeNode[];
					//TreeNode allPart = new TreeNode();	
					
					bool idFlag = false;
					bool pNameFlag = false;
					bool avaFlag = false;
					bool priceFlag = false;
					
					string strName = "";
					string strValue = "";
					
					while (xmlReader.Read()) {
				
						switch (xmlReader.NodeType) {
							case XmlNodeType.Element:
								strName = xmlReader.Name;
								switch (strName) {
									case "Id":
										idFlag = true;
										break;
									case "Part_Name":
										pNameFlag = true;
										break;
									case "Total_Available":
										avaFlag = true;
										break;
									case "Price":
										priceFlag = true;
										break;
								}
								break;
							case XmlNodeType.Text:
								strValue = xmlReader.Value;
								
								if (idFlag) {
									//id = new TreeNode(strValue);
									strid = strValue;
								}
								if (pNameFlag) {
									pName = new TreeNode(strValue);
								}
								if (avaFlag) {
									ava = new TreeNode(strValue);
								}
								if (priceFlag) {
									price = new TreeNode(strValue);
									TreeNode[] part = new TreeNode[]{pName,ava,price};
									TreeNode allPart = new TreeNode(strid,part);
									tvData.Nodes.Add(allPart);
								}
								
								idFlag = false;
								pNameFlag = false;
								avaFlag = false;
								priceFlag = false;
								
								break;
							case XmlNodeType.EndElement:
								break;
						}
					}
				}
			}			
		}
	}
}
